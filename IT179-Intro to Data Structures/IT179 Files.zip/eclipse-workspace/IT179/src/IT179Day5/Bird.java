package IT179Day5;

public class Bird extends Pet {

	private String color;

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public void eat() {
		System.out.println(getName() + "eating Bird food!");
	}

}
