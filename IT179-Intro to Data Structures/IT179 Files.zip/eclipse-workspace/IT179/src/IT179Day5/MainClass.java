package IT179Day5;

public class MainClass {

	public static void main(String[] args) {
		/*
		Pet pet1 = new Dog();
			// Cannot do Dog dog1 = new Pet(); since the dog could be anything. The dog is a pet but the pet is not always the dog.
			// Any method you want to call for this object must be in the "Pet" class.
			// Say you want to call breed but you don't want to add breed to the Pet method. To overcome this, do the following:
		pet1.eat();
		//pet1.setBreed(); does not work since we do not have a breed in the pet class. 
		// Make sure the object is a dog before doing this or else it wont work.
		((Dog)pet1).setBreed("huskey");
		System.out.println(pet1);
		*/
		
		//Showing example of issue. java will not show it's an issue since it hasn't compiled it yet. You cannot cast Dog to a Cat.
		/*Pet pet2 = new Cat();
		((Dog)pet2).setBreed("huskey");
		System.out.println(pet2);
		*/
		
		/*Here's a way to check if it is an instance of that Dog class
		Pet pet2 = new Cat();
		if (pet2 instanceof Dog) {
			((Dog)pet2).setBreed("huskey");
			}
		System.out.println(pet2);
		*/
		
		// Summary of learned code
		Pet[] pets = new Pet[100];
		pets[0] = new Dog();
		pets[1] = new Cat();
		pets[2] = new Dog();
		
		for (int i = 0; i < 3; i++) { // Only three have objects in array, that's why we're only doing it 3 times.
			if (pets[i] instanceof Dog) {
				((Dog)pets[i]).setBreed("huskey");
			} else if (pets[i] instanceof Cat) {
				((Cat)pets[i]).setLives(7);
			}
		}
		
		for (int i = 0; i < 3; i++) {
			System.out.println(pets[i]);
		}
		
		/*
		Pet [] pets = new Pet[100]; // These are references. Did not create any objects yet. Created an array of Pet and only storing 100 object references which are all pointing to null.
		pets[0] = new Dog();
		pets[1] = new Cat();
		pets[2] = new Bird();
		// Can have an array of pets and fill it with any kind of pet. Since the dog is a pet, I can point to that dog with a pet reference. Same thing with cat, bird, and monkey.
		for (int i = 0; i < 3; i++)  // 3 since we only have 3 objects. Everything else will just return "null" since they have no objects
			pets[i].eat();
		*/
		
		/* The above code is much more efficient than the below code
		Cat [] cats = new Cat[100];
		Dog [] dogs = new Dog[100];
		
		// Initialize the cat objects
		for(int i = 0; i < cats.length; i++) {
			cats[i] = new Cat();
		}
		
		for(int i = 0; i < cats.length; i++) {
			cats[i].eat();
		}
		
		// Initialize the dog objects
		for(int i = 0; i < dogs.length; i++) {
			dogs[i] = new Dog();
		}
		
		for(int i = 0; i < cats.length; i++) {
			dogs[i].eat();
		}
		*/
	}
}

/* Student stu1; is not an object. It is an object reference. the part "new Student();" is an object.
	Pet pet = newDog(); means object reference Pet pet references the object new Dog();



	original code:
		Cat cat1 = new Cat();
		cat1.setName("sprinkles");
		Dog dog1 = new Dog("sal", "huskey");
		dog1.setName("sal");
		//cat1.eat();
		//dog1.eat();
		Bird bird1 = new Bird();
		bird1.setName("tweety");
		//bird1.eat();
		
		System.out.println(dog1);
		System.out.println(cat1);
		System.out.println(bird1);
	}




*/

//Static method means you did not need to create an object to use a specific method. 