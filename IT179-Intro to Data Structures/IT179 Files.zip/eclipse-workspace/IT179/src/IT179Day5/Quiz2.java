package IT179Day5;

import java.util.ArrayList;
import java.util.Random;

public class Quiz2 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>(49);
		Random rand = new Random();
		for (int i = 0; i < 50; i++) {
			list.add(rand.nextInt(10) + 1);
		}
		for (Integer k: list) {
			System.out.println(k);
		}
	}
}
