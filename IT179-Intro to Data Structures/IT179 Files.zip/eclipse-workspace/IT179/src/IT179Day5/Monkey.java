package IT179Day5;

public abstract class Monkey extends Pet{

}