package IT179Practice;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;

public class practice {

	public static void main(String[] args) {
		int rows = 0;
		int columns = 0;
		try {
			Scanner fileReader = new Scanner(new File("Grades.csv"));
			while (fileReader.hasNext()) {
				String line = fileReader.nextLine();
				String[] lnArray = line.split(",");
				rows++;
				columns = lnArray.length;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println("Rows: " + rows + " Columns: " + columns);
		// End of Reading File
	}

}

/*
		ArrayList<Double> numberList= new ArrayList<> ();
		DecimalFormat f = new DecimalFormat("##");
		
		for (int i = 0; i < 50; i++) 
			numberList.add(Math.random() * 50);
		
		for (double k : numberList) {
			System.out.println(Math.round(k));
		
		}

*/