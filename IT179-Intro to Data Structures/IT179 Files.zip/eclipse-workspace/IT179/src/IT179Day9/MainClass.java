package IT179Day9;

import java.util.LinkedList;

public class MainClass {

	public static void main(String[] args) {
		MySingleList<String> list = new MySingleList<>(); // Points to "head" and "size". Head = null, and Size = 0.
		list.addFirst("sam"); // We are taking the item, "sam", and pointing the head to a new node, "sam", and incremented the size by one.
		//System.out.println(list.getFirstData());
		list.addFirst("mike");
		//System.out.println(list.getFirstData());
		list.addLast("last");
		list.print();
		list.removeLast();
		list.print();
	}

}


/*
		System.out.println(node0.data);
		//System.out.println(node1.data);
		System.out.println(node0.next.data);


		If Nodes are Public:
			Node<String> node1 = new Node<>("sam"); // Data is pointing to "sam". Next is pointing to null.
			Node<String> node0 = new Node<>("mike", node1); // Data is pointing to "mike". Next is pointing to whatever is being pointed at "node1".
			node0.next.next = new Node<String>("tim"); // Could also write "node1.next". It points to the same thing.
			System.out.println(node0.data);
			System.out.println(node0.next.data); // or node1.data
			System.out.println(node0.next.next.data); // or node1.next.data
*/
