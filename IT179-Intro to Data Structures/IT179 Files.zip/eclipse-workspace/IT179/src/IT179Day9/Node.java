package IT179Day9;

import java.util.ArrayList;

public class Node<E> { //Using that 'E' as a data type in our class.

	public E data; // Creates the data type 'E'. Any time you pass 'E', it will be considered a string since that's declared in mainclass.
	public Node<E> next; // Points to the next node in the list.
	
	public Node(E data) // Default constructor. (You know data directly and next data will be null).
	{
		this.data = data;
	}
	
	
	public Node(E data, Node<E> next) // Pass the data and the next.
	{
		this.data = data;
		this.next = next;
	}
}

// You should not be able to create a node (if private) without LinkedList. The only way to create a node is to do LinkedList.add(data); We do not want to create any floating nodes on their own.