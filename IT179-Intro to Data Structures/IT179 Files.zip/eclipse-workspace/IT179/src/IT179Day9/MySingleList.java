package IT179Day9;

import java.util.ArrayList;

public class MySingleList<E> {
	private Node<E> head; // "head" will basically point to X element in the list.
	private int size;
	
	public void addFirst(E item) 
	{
		head = new Node<E>(item, head);
		
		size++;
	}
	
	public void print() {
		Node<E> current = head;
		while (current != null) {
			System.out.println(current.data + " ");
			current = current.next;
		}
	}
	
	public void addLast(E item) {
		Node<E> current = head;
		if (isEmpty()) 
			addFirst(item);
		else {
			while (current.next != null)
				current = current.next;
			addAfter(item, current);
		}
	}
	
	public void addAfter(E item, Node<E> node) {
		node.next = new Node<E>(item, node.next);
		size++;
	}
	
	public void removeLast() {
		Node<E> checker = head;
		Node<E> temp = head;
		if (isEmpty()) 
			System.out.println("Empty");
		else {
			while (checker.next != null) {
				temp = checker;
				checker = checker.next;
			}
			temp.next = null;
			size--;
		}

	}
	
	public E getFirstData() 
	{
		return head.data;
	}
	
	public E removeFirst()
	{
		Node<E> temp = head;
		if(isEmpty() == false)
		{
			head = head.next;
			size--;
			E result = temp.data;
			temp = null;
			return result;
		}
		return null;
	}
	
	//Quiz 4
	public void addCenter(E item) {
		Node<E> current = head;
		if (head == null)
			head = new Node<E>(item);
		else {
			for (int i = 0; i < (size / 2) - 1; i++) 
				current = current.next;
			current.next = new Node<E>(item, current.next);
		}

	}
	
	private Node<E> getNode(int index) {
		Node<E> current = head;
		for (int i = 0; i < index && current != null; i++) 
			current = current.next;	
		return current;
	}
	
	public E get(int index) {
		if (index <0 || index >= size) 
			throw new IndexOutOfBoundsException(Integer.toString(index));
		Node<E> node = getNode(index);
		return node.data;
	}
	
	public E set(int index, E data) {
		if (index <0 || index >= size) 
			throw new IndexOutOfBoundsException(Integer.toString(index));
		Node<E> node = getNode(index);
		E value = node.data;
		node.data = data;
		return data;
	}
	
	public boolean add(E item) {
		if (isEmpty()) {
			addFirst(item);
			return true;
		}
		Node<E> node = getNode(size - 1);
		addAfter(item, node);
		return true;
	}
	
	public void add(int index, E item) {
		if (index <0 || index >= size) 
			throw new IndexOutOfBoundsException(Integer.toString(index));
		if (index == 0)
			addFirst(item);
		Node<E> node = getNode(index - 1);
		addAfter(item, node);
	}
	
	public boolean isEmpty() 
	{
		if (head!= null) 
			return false;
		return true;
	}
	
	public void addItem(E item)
	{
		head.next = new Node<E>(item);
		size++;
	}
	
	private static class Node<E> { //Using that 'E' as a data type in our class.

		private E data; // Creates the data type 'E'. Any time you pass 'E', it will be considered a string since that's declared in mainclass.
		private Node<E> next; // Points to the next node in the list.
		
		private Node(E data) // Default constructor. (You know data directly and next data will be null).
		{
			this.data = data;
		}
		
		
		private Node(E data, Node<E> next) // Pass the data and the next.
		{
			this.data = data;
			this.next = next;
		}
	}
	
	public void printReversed(E data) {
		if (isEmpty()) 
			System.out.println("Empty List");
		else {
			Node<E> current = head;
			while (current.next != null) { 
				current = current.next;
			}
			while (current != null) {
				//System.out.println(current.data);
				//current = current.prev;
			}
		}
	}
	
	//Exam 1 Question
	public void addBulk(ArrayList<E> list) 
	{
		Node<E> current = head;
		if (head == null)
		{
			head = new Node<E>(list.get(0));
			size++;
			for (int i = 1; i < list.size(); i++)
			{
				current.next = new Node<E>(list.get(i), current.next);
				current = current.next;
				size++;
			}
		} else 
		{
			while (current.next != null)
				current = current.next;
			for (int i = 0; i < list.size(); i++)
			{
				current.next = new Node<E>(list.get(i), current.next);
				current = current.next;
				size++;
			}
		}
	}
	
	//Exam 1 Question
	public MySingleList<E> reverse() 
	{
		MySingleList<E> result = new MySingleList<>();
		Node<E> current = head;
		while (current != null)
		{
			result.head = new Node<E>(current.data, result.head);
			current = current.next;
			result.size++;
		}
		return result;
		
	}
	
	public boolean checkSorted() 
	{
		if (size <= 0 || head == null)
			return true;
		
		Node<E> current = head;
		
		while (current.next != null)
		{
			if (current.data != current.next.data)
				return false;
			current = current.next;
		}
		return true;
	}
	
	//11/02 EXAMPLE (RECURSIVE METHOD)
	public int size() {
		if (head == null)
			return 0;
		return size(head);
	}
	
	private int size(Node<E> node) 
	{
		if (node.next == null)
			return 1;
		return size(node.next) + 1;
			// Look up: What is a wrapper method? (Wrapper: Called in main method (Cannot call the private class). Helper method: Called from the wrapper method that CAN call the variables in the private class).
	}
}

//Double Linked list will not be on the exam

// Terms are ordered on their exponents x^4, x^3, x^2, x^1, etc.
// Can assume that there are at least two terms
// The user is allowed to enter 0. If x^0, make sure coefficient = 1.
// We can assume that every input in correctly entered.
// They can put either a constant or x^0.
// You have a space between operands ONLY (EX: 4x^5_+_x^3)
// Due date pushed to Friday at 11:55pm