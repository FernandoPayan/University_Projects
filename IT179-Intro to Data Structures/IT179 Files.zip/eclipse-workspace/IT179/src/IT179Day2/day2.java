package IT179Day2;

public class day2 {

	public static void main(String[] args) {
		String name = "";
		Student stu1 = new Student("sam"); // Object
		Address ad1 = new Address(1, "main", "normal", 61000); // Object
		Student stu2 = new Student("mike", 19, 4.0, ad1); // Object
		stu1.setAddress(ad1);
		stu1.getAddress().setNum(2);
		System.out.println(stu2.getAddress());
		System.out.print(stu1.getAddress());
		
	}
}