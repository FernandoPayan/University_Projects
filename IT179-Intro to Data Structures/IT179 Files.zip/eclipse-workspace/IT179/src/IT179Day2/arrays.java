package IT179Day2;

public class arrays {

	public static void main(String[] args) {
		// int [] grade = new int [3]; // Array has the size of 3.
		int [] grade = {1, 2, 3}; // "grade" itself is an object. "new int" is the data type. The size of the array is 3.
		
		
		for (int i = 0; i < grade.length; i++) {
			System.out.println(grade[i]);
		}

	}

}
