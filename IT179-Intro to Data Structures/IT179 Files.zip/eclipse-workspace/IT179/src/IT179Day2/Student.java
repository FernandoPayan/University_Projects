package IT179Day2;

public class Student {
	private String name;
	private int age;
	private double gpa;
	private Address address;
	
	public Student (String name) { // Constructor
		this.name = name;
		this.age = 18;
		this.gpa = 4.0;
	}

	public Student(String name, int age, double gpa, Address address) { // Constructor
		this.name = name;
		this.age = age;
		this.gpa = gpa;
		this.address = new Address(address.getNum(), address.getStreet(), address.getCity(), address.getZip());
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = new Address(address.getNum(), address.getStreet(), address.getCity(), address.getZip());
	}
	
	/*public String toString() { // This prevents the output from giving a random gibberish string
		return this.name + " " + this.age + " " + this.gpa;
	}*/

	@Override
	public String toString() { // Retrieved from shortcut
		return "Student [name=" + name + ", age=" + age + ", gpa=" + gpa + "]";
	}
	
	
}