package IT179Day2;

public class Address {
	private int num;
	private String street;
	private String city;
	private int zip;
	
	public Address(int num, String street, String city, int zip) { // Constructor
		this.num = num;
		this.street = street;
		this.city = city;
		this.zip = zip;
	}
	// Getter and Setters
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}
	
	// toString method
	@Override
	public String toString() {
		return "Address [num=" + num + ", street=" + street + ", city=" + city + ", zip=" + zip + "]";
	}
	
	
	
}
