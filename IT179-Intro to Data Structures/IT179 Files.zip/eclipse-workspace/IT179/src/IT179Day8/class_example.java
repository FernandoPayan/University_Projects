package IT179Day8;

import java.util.ArrayList;

import IT179Day5.Cat;
import IT179Day5.Dog;
import IT179Day5.Pet;
import java.util.LinkedList;

public class class_example {

	public static void main(String[] args) {
		ArrayList<Integer> test = new ArrayList<>(20);
		test.add(2);
		System.out.println(test);
		
		LinkedList<Integer> test1 = new LinkedList<>();
	}

	public static Dog[] getMyDogs(Pet [] pets) {		
		
		int counter = 0;
		for (int i = 0; i < pets.length; i++)  // Only three have objects in array, that's why we're only doing it 3 times.
			if (pets[i] instanceof Dog) 
				counter++;
		
		Dog [] dogs = new Dog[counter];
		int count = 0;

		for (int j = 0; j < pets.length; j++) 
			if (pets[j] instanceof Dog) {
				dogs[count] = (Dog)pets[j];
				count++;
			}
		
		return dogs;
	}
}
