package IT179Day7;

public interface Animal {
	
	String ZOO_NAME = "Bloomington Zoo";
	void move(); // (This is a method) By default, this is an abstract method. Adding "public abstract" is optional. In professional conventions, you would not add "public abstract".
	
}

/* Notes
Unless declared private, any field/variable you create in an interface is "public static final"/

*/