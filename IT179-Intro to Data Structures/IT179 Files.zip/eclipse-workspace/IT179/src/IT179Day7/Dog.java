package IT179Day7;

public class Dog extends Pet{ // Writing "extends Pet" gets all the methods in the Pet class and extends it onto this class.
	
	public Dog() {
		
	}
	
	public Dog(String name, String breed) {
		//this(); This calls upon the default constructor within the class (Dog()).
		super(name); // Calls parent constructor (specifically, the default. Doesn't matter if we write it since java provides default constructor).
		this.breed = breed;
		//"this" refers to the the variable in the current class. "super" calls upon the superclass/parent class.
	}
	
	private String breed;

	public void move() {
		System.out.println(" we are moving");
		
	}
	
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	public void eat() {
		System.out.println(getName() + "eating Dog food!");
	}
	
	public String toString() {
		return super.toString() + " " + this.breed; // If want the name in super class, use super.getName. If you want name from this local class, you'd use this.getName().
	}
}

// Private values means it's only accessible within that class.
// Protected values means it's accessible from inheriting classes and same classes (Pet, Dog, Cat, etc. are all in the same family so they can use protected values).
// Public values means it can be accessible from any class.
// Overloading: Same method name but different arguments/parameter lists. 
// Overriding: Same method with same arguments/parameter lists.