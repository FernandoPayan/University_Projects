package IT179Day7;

public abstract class Pet implements Animal{ // This is the parent class. "abstract" means you cannot create an object from that class.
	private int tag;
	private String name;
	
	public Pet() {
		
	}
	
	public Pet (String name) {
		this.name = name;
	}
	
	
	public int getTag() {
		return tag;
	}
	public void setTag(int tag) {
		this.tag = tag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//public abstract void eat(); // Any class that's inheriting the Pet class must have their own "eat" method. Once you have an abstract method, the class must be abstract.
		// now all sub-classes must have an eat method since this is an abstract method
		// Think of it as an incomplete method. needs to be completed by a subclass/ child class.
		// Abstract methods have no body. Must end with a semi-colon.
	public void eat() {

	}
	
	public String toString() {
		return this.name + " " + this.tag;
	}

}