package IT179Day7;

public class Cat extends Pet { // Writing "extends Pet" gets all the methods in the Pet class and extends it onto this class.
	private int lives;

	public int getLives() {
		return lives;
	}
	public void setLives(int lives) {
		this.lives = lives;
	}
	
	public void eat() { // Since you already implemented this "eat" method, there is no error.
		System.out.println("eating cat food!");
	}
	
	public void move() {
		System.out.println(" we are moving");
		
	}
}
