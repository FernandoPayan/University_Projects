package IT179Day7;

public abstract class Monkey extends Pet{

}