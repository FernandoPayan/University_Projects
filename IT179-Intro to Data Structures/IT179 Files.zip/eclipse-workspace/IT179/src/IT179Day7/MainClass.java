package IT179Day7;

import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		Animal dog1 = new Dog(); 
		Animal cat1 = new Cat();
		((Pet)cat1).eat();
		((Dog)dog1).eat();
		
		//ArrayLists cannot store primative data types (such as int, double, etc). Can only store objects (such as Integer, Double, etc).
		ArrayList<String> list = new ArrayList<>();
	}
}