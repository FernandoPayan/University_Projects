package BinaryTree;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {

	public static void main(String[] args) {
		BinaryT<Integer> left = new BinaryT(6, null, null);
		BinaryT<Integer> right = new BinaryT(16, null, null);
		BinaryT tree = new BinaryT(15, left, right);
	
		
		//System.out.println(tree.toString());
		
		try 
		{
			//ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("test.txt")); // Similar to print writer and file writer
			//out.writeObject(tree);
			
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("test.txt"));
			@SuppressWarnings("unchecked")
			BinaryT<Integer> tree2 = (BinaryT)in.readObject();
			System.out.println(tree2);
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e)
		{
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
		
	}

}
