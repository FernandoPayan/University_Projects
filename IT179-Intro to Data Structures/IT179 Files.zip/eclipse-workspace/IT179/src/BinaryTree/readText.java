package BinaryTree;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readText {

	public static void main(String[] args) throws FileNotFoundException {
		// Text document must be put into project folder in order to read it
		FileInputStream fis = new FileInputStream("textfile.txt");
		Scanner in = new Scanner(fis);
		
		while(in.hasNext()) {
			String line = in.nextLine();
			System.out.println(line);

			for (int i = 0; i < line.length(); i++)
			{
				if (line.charAt(i) == 'D')
				{
					System.out.println("left");
				} else if (line.charAt(i) == 'd')
				System.out.println("right");
					
			}
		}

	}

}
