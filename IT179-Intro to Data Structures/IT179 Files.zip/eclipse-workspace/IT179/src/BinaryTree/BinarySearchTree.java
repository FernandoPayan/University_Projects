package BinaryTree;

import BinaryTree.BinaryT.Node;

public class BinarySearchTree<E extends Comparable<E>> extends BinaryT<E>{
	
	public E find(E target)
	{
		return find(root, target);
	}
	
	private E find(Node<E> localRoot, E target)
	{
		if (localRoot == null)
			return null;
		// Compare the target with the data field at the root (0 == found target/equal, -1 = less than, 1 = greater than)
		int result = target.compareTo(localRoot.data);
		if (result == 0)
			return localRoot.data;
		else if (result < 0) // Means target is less than the root
			return find(localRoot.left, target);
		else
			return find(localRoot.right, target);
	}
	
	protected E findLargestChild(Node<E> parent) //Finds the largest element in a BST given the parent node.
	{
		if (parent.right == null)
		{
			return parent.data;
		}
		
		return findLargestChild(parent.right);
		
		/* Class Method
		 	if (parent.right.right == null)
			{
				E returnValue = parent.right.data;
				parent.right = parent.right.left;
				return returnValue;
			} else {
				return findLargestChild(parent.right);
			}
		 */
	}
	
	protected boolean addReturn = false;

	public boolean add(E item)
	{
		root = add(root, item);
		return addReturn;
	}
	
	private Node<E> add(Node<E> localRoot, E item) 
	{
		if (localRoot == null)
		{
			addReturn = true;
			return new Node<E>(item);
		}
		int res = item.compareTo(localRoot.data);
		if (res == 0)
		{
			addReturn = false;
			return localRoot;
		}
		else if (res < 0)
		{
			add(localRoot.left, item);
			return localRoot;
		}
		else
		{
			localRoot.right = add(localRoot.right, item);
			return localRoot;
		}

	}
	
	protected E deleteReturn;
	
	public E delete(E target)
	{
		this.root = delete(root, target);
		return deleteReturn;
	}
	
	private Node<E> delete(Node<E> localRoot, E item)
	{
		// If the tree is empty OR reach end of the tree and it does not contain item
		if (localRoot == null) 
		{
			deleteReturn = null;
			return localRoot;
		}		
		
		//If the tree is not empty
		int compareResult = item.compareTo(localRoot.data); // -1 means look to left. 0 means delete root. 1 means go to the right.
		
		if (compareResult < 0) // We are going to delete from the right subtree
		{
			//We are going to delete from the left sub tree, so we need to change our reference to see the new children.
			localRoot.left = delete(localRoot.left, item);
			return localRoot;
		} else if (compareResult > 0) // We are going to delete from the right subtree
		{
			localRoot.right = delete(localRoot.right, item);
			return localRoot;
		} else // We found the target. We return the child back to the original caller
		{
			deleteReturn = localRoot.data;
			// If only right child
			if (localRoot.left == null)
				return localRoot.right;
			// If only left child
			else if (localRoot.right == null)
				return localRoot.left;
			// If more than one child
			else
			{
				if (localRoot.left.right == null) // If the left does not have any right children
				{
					localRoot.data = localRoot.left.data;
					localRoot.left = localRoot.left.left;
					return localRoot;
				} else {
					localRoot.data = findLargestChild(localRoot.left);
					return localRoot;
				}
			}
		}

	}
}

/*Review this. Most likely a quiz. 
SAY ON PART 2: Pre: This binary tree is storing any data typing that extends upon the Comparable interface
For removal of an element/root in a tree, you can either get the smallest value from the right subtree (from the value you're removing),
or you can get the largest value in the left subtree (from the value you're removing)
*/