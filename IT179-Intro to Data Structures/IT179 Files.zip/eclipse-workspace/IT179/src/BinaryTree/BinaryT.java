package BinaryTree;

import java.io.Serializable;

public class BinaryT<E> implements Serializable  {
	protected Node<E> root;
	protected BinaryT()
	{
		
	}
	
	protected BinaryT(Node<E> root)
	{
		this.root = root;
	}
	
	public BinaryT(E data, BinaryT<E> leftSub, BinaryT<E> rightSub)
	{
		root = new Node(data);
		
		if (leftSub != null)
			root.left = leftSub.root;
		else
			root.left = null; // This isn't necessary since by default, root.left is equal to null.
		
		if (rightSub != null)
			root.right = rightSub.root;
		else
			root.right = null; // This isn't necessary since by default, root.right is equal to null.
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		preOrder(root, 1, sb);
		return sb.toString();
	}
	
	private void preOrder(Node<E> node, int level, StringBuilder sb)
	{
		for (int i = 1; i < level; i++)
			sb.append("  ");
		if (node == null)
			sb.append("null\n");
		else
		{
			sb.append(node.data + "\n");
			preOrder(node.left, level + 1, sb);
			preOrder(node.right, level + 1, sb);

		}
	}
	
	protected boolean isLeaf()
	{
		if (root == null) // If we do not have a tree
			return false;
		return (root.left == null && root.right == null);
	}
	
	protected BinaryT<E> getLeftSubTree()
	{
		if (root != null && root.left != null)
			return new BinaryT<E>(root.left);
		return null;
	}
	

	// Node Class
	protected static class Node<E> implements Serializable {
		protected E data;
		protected Node<E> left;
		protected Node<E> right;
		
		
		public Node(E data)
		{
			this.data = data;
		}		
	}
}

/*
Linked List (Node<E> data, head, size)
Double Linked List (Node<E> data, head, tail, size)
Stack (top, push, pop)
Queue (head, offer, poll)
Array (E[] name = new e[size]; OR = {E, E2, E3};)
ArrayList (ArrayList<E> name = new ArrayList<>(size);)
(NOT IN CLASS: Learn about hashmaps)

Parent (Top Node/ Root)
Child (Descendant of the parent | Relationship of parent-child is called ancestor-descendant)
Sibling (Children who share a parent)
Leaf node (Child with no descendant)
Subtree - A subtree of a node is a tree whose root is a child of that node
Root - Start of a tree/subtree
Height - Number of nodes in the longest path from the root node to a leaf node (Could also check what's the last level)


Binary Tree (Each node will have two subtree)
A set of nodes T is a binary tree if either of the following is true
- T is empty
- Its root node has two Subtrees, T(L) and T(R), such that T(L) and T(R) are binary Trees
(T(L) = left subtree; T(R) = right subtree);

Binary Search Tree (Left side's values will be less than the root. Right side's values have to be greater than the root)
A set of nodes T is a binary search tree if either of the following is true
- T is empty
- If T is not empty, its root node has two subtrees, T(L) and T(R), such that T(L) and T(R) are binary search trees and the value in the root node of T is greater than all values in T(L) and is less than all values in T(R).

General Tree (Nodes can have any number of subtrees)
Full Binary Tree (Binary tree where all nodes have either 2 children or 0 children (leaf nodes)
Perfect Tree (Full binary tree of height n with exactly 2^n - 1 nodes) (EX: n = 3 and 26n - 1 = 7. This means we have 3 levels and 7 nodes (including root))
Complete Binary Tree (Perfect binary tree through level n - 1 with some extra leaf nodes at level n (the tree height), all toward the left) (Basically all right child MUST have a left child.)


Tree Traversals
Inorder: Traverse T(L), visit root node, traverse T(R)
Preorder: Visit root node, traverse T(L), traverse T(R)
Postorder: traverse T(L), traverse T(R), visit root node

Following a tree from the left is known as the Euler tour.

Protected: Anyone in package
Private: Only that class
Public: Anyone, even if not in the same package
(Note: Whenever you create data structures, they should be in a seperate package than your main class.


Final Exam Notes:
Final Exam will be on everything but will primary focus on recursion and trees
Can have a cheat sheet (Def have add method, remove method (all situations: no child, one child, two children)

*/