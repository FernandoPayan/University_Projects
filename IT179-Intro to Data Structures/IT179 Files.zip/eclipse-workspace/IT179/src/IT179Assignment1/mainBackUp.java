/*
package IT179Assignment1;

import java.util.Scanner;


public class MainClass {

	public static void main(String[] args) {
		// Declaration of objects
		StudentReport report = new StudentReport();
		int userInput = 0;
		
		// Introduction to program
		
		
		while (true) { // This loop keeps the prompts displayed after each selection until we exit the program.
			Scanner input = new Scanner(System.in);
			System.out.println("Please select an option. Enter the number associated with option to select it:\n1. Enter the file name to process\n2. Print a list of all students\n3. Generate a report card for a specific student\n4. Display statistics\n5. Exit");
			userInput = input.nextInt();
			
			
			switch (userInput) {
			case 1: { // Option 1: Enter the file name to process
				System.out.print("Enter the file name including the extension: ");
				report.readFile(input.next());
				break;
				}
			case 2: { // Option 2: Print a list of all students
				System.out.println("\n" + report.printStudents(report.students));
				break;
			}
			case 3: { // Option 3: Generate a report card for a specific student
				System.out.print("Enter the name of the student: ");
				break;
				}
			case 4: { // Option 4: Display statistics
				break;
				}
			case 5: { // Option 5: Exit
				System.out.println("Terminating program...");
				System.exit(0);
				break;
				}
			}
			System.out.print("\n"); // Creates a space between the last prompt and the next.
		}
	}
}

//Back up of StudentReport

package IT179Assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import IT179Day2.Address;

public class StudentReport {
	
	String filename;
	String [][] grades;
	String [] students;
	String[] gradedItems;

	// Getters and Setters
	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


	public String[][] getGrades() {
		return grades;
	}


	public void setGrades(String[][] grades) {
		this.grades = grades;
	}


	public String[] getStudents() {
		return students;
	}


	public void setStudents(String[] students) {
		this.students = students;
	}


	public String[] getGradedItems() {
		return gradedItems;
	}


	public void setGradedItems(String[] gradedItems) {
		this.gradedItems = gradedItems;
	}
	// End of Getters and Setters
	
	public StudentReport() { // Default constructor
		this.filename = "Grades.csv";
		this.grades = new String [20][9]; // Ask professor is this is instantiating the array.
	}
	
	
	public StudentReport(String file, String[][] array) { // A constructor that will take the file name and instantiate the arrays.
		this.filename = file;
		this.grades = array;
	}

	public void readFile(String file) { // This will read the .csv file and store the values in the arrays we have.
		int rows = 0;
		int columns = 0;
		ArrayList <String> string = new ArrayList<> ();
		try {
			Scanner fileReader = new Scanner(new File(file));
			while (fileReader.hasNext()) { 
				String line = fileReader.nextLine();
				// Counts rows and columns
				String[] lnArray = line.split(",");
				rows++;
				columns = lnArray.length;	
				
				// Gets value of next thing in csv
				Scanner scan = new Scanner(line);
				scan.useDelimiter(",");
				while (scan.hasNext()) {							
					string.add(scan.next());
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// End of Reading File
		
		// Update variables
		this.grades = new String[rows][columns];
		this.students = new String[rows];
		this.gradedItems = new String[columns];
		// Update values for the arrays "grades" and "students".
		int counter = 0;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				this.grades[i][j] = string.get(counter);
				counter++;
			}
			students[i] = grades[i][0];
		}
		
		// Updates the values for the array "gradedItems".
		for (int k = 0; k < this.grades[0].length; k++)
			this.gradedItems[k] = this.grades[0][k];
	}	

	public void writeFile() { // This will generate a report card for the selected student and save it as a .txt file. The name of the file should be the student�s name.
		
	}
	
	public String printStudents(String[] array) {
		StringBuilder newString = new StringBuilder();
		for (int i = 1; i < array.length; i++) 
			newString.append(array[i] + "\n");
		return newString.toString();
	}
}
*/