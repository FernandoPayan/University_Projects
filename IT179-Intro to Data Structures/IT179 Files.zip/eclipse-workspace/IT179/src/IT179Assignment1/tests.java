package IT179Assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class tests {

	public static void main(String[] args) {
		// Default Constructor
		StudentReport test = new StudentReport();
		
		// Defined parameters
		String[][] test2 = new String [0][0];
		StudentReport test1 = new StudentReport ("Testing!", test2);

		
		test.readFile(test.filename);		
		System.out.println(test.printStudents(test.gradedItems));
		System.out.println(test.students.length);
		System.out.println(test.gradedItems.length);
	}

}
