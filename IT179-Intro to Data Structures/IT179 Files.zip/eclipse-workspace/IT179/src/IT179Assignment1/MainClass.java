package IT179Assignment1;

import java.util.Scanner;


public class MainClass {

	public static void main(String[] args) {
		// Declaration of objects
		StudentReport report = new StudentReport();
		int userInput = 0;
		
		// Introduction to program
		
		
		while (true) { // This loop keeps the prompts displayed after each selection until we exit the program.
			Scanner input = new Scanner(System.in);
			System.out.println("Please select an option. Enter the number associated with option to select it:\n1. Enter the file name to process\n2. Print a list of all students\n3. Generate a report card for a specific student\n4. Display statistics\n5. Exit");
			userInput = input.nextInt();
			
			
			switch (userInput) {
			case 1: { // Option 1: Enter the file name to process
				System.out.print("Enter the file name including the extension: ");
				report.readFile(input.next());
				break;
				}
			case 2: { // Option 2: Print a list of all students
				System.out.println("\n" + report.printStudents(report.students));
				break;
			}
			case 3: { // Option 3: Generate a report card for a specific student
				System.out.print("Enter the name of the student: ");
				break;
				}
			case 4: { // Option 4: Display statistics
				break;
				}
			case 5: { // Option 5: Exit
				System.out.println("Terminating program...");
				System.exit(0);
				break;
				}
			}
			System.out.print("\n"); // Creates a space between the last prompt and the next.
		}
	}
}