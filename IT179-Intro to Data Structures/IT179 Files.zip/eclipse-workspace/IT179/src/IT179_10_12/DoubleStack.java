package IT179_10_12;

import java.util.Deque;
import java.util.LinkedList;

public class DoubleStack {

	private Deque<Integer> stacks = new LinkedList<>();
	private int size1;
	private int size2;
	
	public boolean empty(int stackNumber)
	{
		if (stackNumber == 1)
			if (size1 == 0)
				return true;
		if (stackNumber == 2)
			if (size2 == 0)
				return true;
		return false;
		
	}
	
	public Integer peek(int stackNumber) // Must be "Integer" because you can return null. If it's "int", you cannot return null.
	{
		if (stackNumber == 1 && size1 != 0)
			return stacks.peekFirst();
		else if (stackNumber == 2 && size2 != 0)
			return stacks.peekLast();
		return null;
	}
	
	public void pop(Integer value, int stackNumber)
	{
		if (stackNumber == 1)
		{
			stacks.offerFirst(value);
			size1++;
		} 
		if (stackNumber == 2)
		{
			stacks.offerLast(value);
			size2++;
		}
	}
}