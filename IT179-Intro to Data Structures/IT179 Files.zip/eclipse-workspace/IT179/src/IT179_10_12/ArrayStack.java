package IT179_10_12;

import java.util.Deque;

public class ArrayStack <E> {
	private E[] data;
	int top = -1;
	
	//@SuppressWarnings("unchecked");
	public ArrayStack()
	{
		data = (E[]) new Object[10];
	}
	
	public E push(E value)
	{
		if (top == data.length - 1) // Checks if we have enough spaces in the array. If we don't, we resize it.
			resize(); 
		top++;
		data[top] = value;
		return value;
	}
	
	public boolean empty()
	{
		if (top == -1)
			return true;
		return false;
	}
	
	public E pop()
	{
		if (top == -1)
			return null;
		return data[top--]; //Gets data at location top, and then it decrements top value by 1.
	}
	
	public E peek()
	{
		if (top == -1)
			return null;
		return data[top];
	}
	
	private void resize()
	{
		E[] temp = (E[]) new Object[data.length * 2];
		for (int i = 0; i < data.length; i++)
			temp[i] = data[i];
		data = temp;
	}
}
