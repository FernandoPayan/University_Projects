package IT179Day3;

public class MainClass {

	public static void main(String[] args) {
		
		
		int[][] grades1 = new int [3][];
		grades1[0] = new int [5]; // Grades at row 0. Creates 5 elements in that array and sets them to 0. (Creates 5 columns.)
		grades1[1] = new int [2]; // Grades at row 1. Creates 2 elements in that array and sets them to 0. (Creates 2 columns.)
		grades1[2] = new int [3]; // Grades at row 2. Creates 3 elements in that array and sets them to 0. (Creates 3 columns.)
		int [][] grades2 = { // two-dimensional array with pre-defined values
				{1, 2, 3},
				{4},
				{7, 8},
		};
		
	

		// Prints the sum of a certain column in grades2 array.
		int sum = 0;
		for (int i = 0; i < grades2.length; i++) { // grades2.length is the # of rows in the array.
			sum = 0;
			for (int j = 0; j < grades2[i].length; j++) { // grades2[i].length prints the length of each row (I.E. how many columns)
				sum += grades2[i][j];
			}
			System.out.println((double)sum/grades2[i].length); // Gets the average of each row. We also cast one of the values so that we get a double result.
		}
	}
	
}
/* Notes
int [][] grades = new int [3][3]; regular two-dimensional array
System.out.println(grades2[0].length);  Prints the length of the number of elements in the row

		for (int i = 0; i < grades2.length; i++) {
			System.out.println(grades2[i][1]); DO NOT USE THIS. Example of an index out of bounds error.
		}
		
		Prints grades2 array.
		for (int i = 0; i < grades2.length; i++) {
			for (int j = 0; j < grades2[i].length; j++) { // J is for each member in that row. I represents the row. If you remove "grades2[i].length" and change it to "grades2.length", you would get an index out of bounds error since it will always assume there are three columns.
				System.out.print(grades2[i][j] + " "); // Prints each element in the row.
			}
			System.out.println();
		}
		
		Prints a certain column in grades2 array.
		for (int i = 0; i < grades2.length; i++) {
			if (1 < grades2[i].length) // Do an if statement to check if there is a value in that column. We pick 1 because the column we are specfically checking is column 1.
				System.out.println(grades2[i][1]); 
		}
		
*/