package IT179Day3;

import java.util.ArrayList;

public class ArrayLists {

	public static void main(String[] args) {
		ArrayList <String> names = new ArrayList<> (); // By default, the capacity of an ArrayList is 10.
		names.add("sam"); // Adds an element to the array list.
		names.add("Fernando");
		names.remove(0); // Removes an element from the array list.
		System.out.println(names.size()); // Prints the size of the array list.
		System.out.println(names.get(0)); // Prints the element at position X (in this case, it's 0).
	}
	
	public static void testing()
	{
		System.out.println("Testing");
	}

}
