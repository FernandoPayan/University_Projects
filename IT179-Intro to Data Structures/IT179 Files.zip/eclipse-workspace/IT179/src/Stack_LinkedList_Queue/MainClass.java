package Stack_LinkedList_Queue;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import IT179_10_12.ArrayStack;

public class MainClass {

	public static void main(String []args)
	{
		//STACK
		Stack<String> names = new Stack<String>();
		names.push("sam");
		names.push("mike");
		names.push("tim");
		
		while (!names.isEmpty()) // While the stack is not empty, it will pop each element and print it out.
		{
			System.out.println(names.pop());
		}
		
		String exp = ("(w*[x+y]/z)");
		System.out.println(check(exp));
		
		// QUEUE
		Queue <String> line = new LinkedList<>();
		line.offer("sam");
		line.offer("mike");
		line.offer("tim");
		
		System.out.println(line.poll());
		System.out.println(line.peek());
		System.out.println(line.poll());
		System.out.println(line.peek());
		System.out.println(line.poll());
		System.out.println(line.peek());
		
		//DEQUE
		Deque<String> test = new LinkedList();
	//	Deque<String> list = new ArrayDeque<>();
	//	ArrayDeque<String> list2 = new ArrayDeque<>();
		test.push("5");
		test.push("4");
		test.push("3");
		test.push("2");
		test.push("1");
		rotate(test, 2);	
		System.out.println(test);

		print("sam");
		System.out.println("Thanks!");
		System.out.print(removeDup("Fernando"));
		System.out.println("\n" + factorial(5));
		System.out.println(fibo(1, 0, 6));
	}
	
	public static void rotate(Deque<String> string, int n)
	{
		if (!string.isEmpty())
			for (int i = 0; i < n; i++)
			{
				string.offerLast(string.pollFirst());
			}

		
		/* MY METHOD
		if (!string.isEmpty())
			for (int i = 0; i < n; i++)
			{
				string.addLast(string.pollFirst());
			}
			
			IT IS PREFERRED TO USE "string.offerLast" INSTEAD OF "string.addLast" BECAUSE
			THE LATTER CAN THROW AN EXCEPTION WHILE THE FORMER IS A BOOLEAN.
		 */		
	}	
	
	public static boolean check(String sentence)
	{
		Stack<Character> expStack = new Stack<Character>();
		char popped;
		for (int i = 0; i < sentence.length(); i++)
		{
			if (sentence.charAt(i) == '(' || sentence.charAt(i) == '[')
				expStack.push(sentence.charAt(i));
			 else if (sentence.charAt(i) == ')' || sentence.charAt(i) == ']')
			{
				if (expStack.isEmpty())
					return false;
				popped = expStack.pop();
				if (sentence.charAt(i) == ')' && popped != '(')
					return false;
				if (sentence.charAt(i) == ']' && popped != '[')
					return false;
			}
		}
		if (expStack.isEmpty())
			return true;
		return false;
	}
	
	public static Stack<Integer> combineStacks(Stack<Integer> s1, Stack<Integer> s2)
	{
		Stack<Integer> result = new Stack<>();
		while (!s1.isEmpty() && !s2.isEmpty())
		{
			if (s1.peek() > s2.peek())
				result.push(s1.pop());
			else
				result.push(s2.pop());
			
		}
		while (!s1.isEmpty())
			result.push(s1.pop());
		
		while (!s2.isEmpty())
			result.push(s2.pop());
		
		return result;
	}
	
	// if returning int
	public static int length(String word)
	{
		if (word == null || word.equals(""))
			return 0;
		return 1 + length(word.substring(1));
	}
	
	// if returning string
	public static void print(String word) // THIS IS A RECURSIVE ALGORITHM
	{
		if (word == null || word.equals(""))
			return; 
	//	System.out.println(word.charAt(0)); THIS PRINTS IT REGULARLY
		print(word.substring(1));
		System.out.println(word.charAt(0)); // THIS PRINTS IT IN REVERSE
	}
	
	public static String removeDup(String s) // THIS IS A RECURSIVE ALGORITHM
	{
		if (s.equals(null) || s.length() <= 1)
			return s;
		if (s.charAt(0) == s.charAt(1))
			return removeDup(s.substring(1));
		return s.charAt(0) + removeDup(s.substring(1)); 
	}
	
	public static int factorial(int num) // THIS IS A RECURSIVE ALGORITHM
	{
		if (num == 0)
			return 1;
		return num * factorial(num - 1);
	}
	
	public static int fibo(int fibCurrent, int fibPrevious, int n) // THIS IS A RECURSIVE ALGORITHM
	{
		if (n == 1)
			return fibCurrent;
		return fibo(fibCurrent + fibPrevious, fibCurrent, n - 1);
	}
	
	public static int count(String s, char c)
	{
		if (s.equals(null) || s.length() <= 1)
			return 0;
		if (s.charAt(0) == c)
			return 1 + count(s.substring(1), c);
		return count(s.substring(1), c);
	}
}	

/* Website Questions
 * Expression Evaluation
 * Rigged Dice
 * Look up Software Development Topics from Amazon
 * 
 * Game class: Player should not have access to game class. The class has control of the players (Selects which player goes next, what methods to use, etc.)
 * Everything in game class should NOT be in player class (Draw method, face down, etc. should be done through the game).
 * Game should only pass the card they're supposed to draw.
 * 
 * Binary Search: (.compareTo) method meaning
 * 0: Equals
 * 1: Above
 * -1: Below
 * 
 * EXAM:
 * Will not ask about recursion. Will only cover DoubleLinkedList, Stacks, Queues, and Deques.
 * What each method will do/operate. Know polymorphism (EX: Cannot create an object of Deque), single linked list, arrays, etc.
 * 
 * You need to know:
 * Chapter 1
 * Chapter 2 (Double Linked List)
 * Chaper 4 (THIS IS THE MOST IMPORTANT)
 * Basics of IT 168 & Appendix A
 * 
 * Poly (Doubled ended queses (Cannot instantiate an object with it. Must use linked list to instansiate it_
 * Casting (Recall the Dog example)
 * 
 * Single linked lists (Not asked directly; may asked to make a stack/queue using a single linked list). (head, data)
 * When removing from single, we only care about the next. 
 * Double linked lists (May ask directly about them. This only have next, previous) (head, tail, data)
 * When removing from double, we are interested in previous so we can move the next to the previous.
 * 
 * For 1st video: A(node) -> B(node) -> C(node)
 * 	With head example: Head - > node - > node (Node B = head.next, Node C = B.next)
 * 
 * head : linked list
 * top : stack
 * front: queue
 * 
 * Remember these!!!
 * push, pop, peek, empty : Stack
 * poll, offer; empty; remove, add; Queue
 * 
 * Find out: What is an API?
 * 
 * NOT BEING ASKED ABOUT CIRCULAR LINKED LIST
*/
