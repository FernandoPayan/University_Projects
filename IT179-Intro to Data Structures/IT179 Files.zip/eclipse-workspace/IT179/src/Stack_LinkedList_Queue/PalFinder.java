package Stack_LinkedList_Queue;

import java.util.Stack;

public class PalFinder {
	private String input;
	private Stack<Character> stack;
	
	public PalFinder(String input)
	{
		this.input = input;
		stack = new Stack<Character>();
	}
	
	private void fillStack() 
	{
		for (int i = 0; i < this.input.length(); i++)
		{
			stack.push(input.charAt(i));
		}
	}
	
	private String buildReverse()
	{
		StringBuilder reverse = new StringBuilder();
		while(!stack.empty())
			reverse.append(stack.pop());
		return reverse.toString();
	}
	
	public boolean isPal()
	{
		return (input.equals(buildReverse()));
	}
}
