package Stack_LinkedList_Queue;
/*
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ArraySearchTest {

	private int []arr = {5, 12, 15, 4, 8, 12, 7};
	@Test
	void firstTest() 
	{
		assertEquals(0, ArraySearch.search(arr, 5), "Test");
	}
	
	@Test
	void lastTest() {
		assertEquals(arr.length-1,ArraySearch.search(arr));
	}
	
	@Test()
	void notInArrayTest() {
		assertEquals(-1,ArraySearch.search(arr, 50), "Test");
	}
}
*/