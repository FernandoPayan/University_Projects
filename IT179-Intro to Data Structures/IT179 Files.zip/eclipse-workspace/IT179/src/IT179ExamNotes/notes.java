package IT179ExamNotes;

public class notes {

	public static void main(String[] args) {

		
		
	}

}

/*
Thursday, Sept 30th
During class time
Covers all the material up to the end of Linked lists (appendix a, ch01, ch02)
No calculators allowed
Open book (Notes must be hand written)

Exam Chapters:
Chapter 1
Chapter 2
Appendix A
Basics of IT 168

Basic topics to know: (Basics of IT 168 & Appendix A)
Data types, variables, operations
Strings
Control structures: selection, looping
Object oriented principles: classes, objects, constructors, methods, toString, APIs
1D Arrays
2D Arrays
Wrapper classes

Chapter 1 Breakdown:
Inheritance
Aggregation
Overriding / overloading
Polymorphism
Abstraction
Interfaces
Casting (Parent reference to child reference so we have access to the methods)
Access modifiers (private, public, protected)

Chapter 2 Breakdown:
Algorithm effciency and big O (how one algorithm is better than other; what makes it efficient)
Arraylists (What makes arraylists better than linked list?) 
Single linked list (What makes linked list better than arraylist?) 
*You'll know what's better by looking at big O 

General things to know: 
How to use arrays, ArrayLists and Linked lists
Understand OOP concepts (How to use inheritance, HOW POLYMORPHISM WORKS, how casting works, what type of classes/objects you can/cannot create objects from)
Understand Big O (What is more efficient? What data structure is more efficient than other in a data structure?)
How Single Linked Lists work and how to implement functionalities in them (How to implement linked list and how to use it/create methods)
*Know how to resize array, how to copy one array to another, etc. Will not be asked functionalities of Arraylists.

Common Mistakes:
Counting items and indices (Any data structure we start at 0. Should always stop at index size - 1. If you go over bounds, you'll get indexoutofbounds error. Visualize examples.)
Method headers (If asked how to write a method, it's important to know if it'll be a void or to return a data item.) Read question carefully, will be asked to create method, how to create, include proper return time. 
Using the requested technique
Data types (casting) (Do you cast it or just change the data type/use different data type?)

Types of Questions (Nothing different from quizzes):
Write methods and statements to achieve a goal (What will this method do?)
General understanding questions
Using classes that inherit or implement other classes or interfaces (How will linked list look after executing code?)

How to win the exam:
Keep an eye on the time
Read the question carefully multiple times and try to break it down into steps
Visualize (draw sample scenarios)
Test your solution





*/
