package IT179Day4;

import java.util.Arrays;

public class Quiz1 {

	public static void main(String[] args) {
		String[][] test = {
			{"sam", "bob", "joe"},
			{"frank", "billy", "tank"},
			{"Nikolai", "Anthony", "John"},
		};

		System.out.println(Arrays.toString(wordGenerator(test)));
	}
	
	public static int[] wordGenerator(String[][] words) {
		int[] result = new int [words.length];
		for (int i = 0; i < words.length; i++) {
			for (int j = 0; j < words[i].length; j++) {
				result[i] += words[i][j].length();
			}
		}
		return result;
	}
}