package IT179Day4;

import java.util.ArrayList;

public class ArrayListCont {

	public static void main(String[] args) {
		ArrayList <String> names = new ArrayList<>();

		System.out.println(names.size()); // There is no elements in the array, so the size is 0, even though the capacity is 10 (default is 10)
	
		for (int i = 0; i < 100; i++) {
			names.add("name");
		}
		
		System.out.println(names.size()); // Will now print 100 since there are 100 elements in the array list.
		System.out.println(names.get(5)); // gets what the value is at position 5
		
		ArrayList <Integer> test = new ArrayList<>();
		test.add(1);
		test.add(2);
		test.add(3);
		test.remove(1);
		System.out.println(test.get(1));
	}
}

/* Notes
Capacity means how much it can hold. Size is how many elements it has.
Capacity is a private value.

Look up what is a method, an object, a constructor, a reference, Wrapper (The Wrapper Classes), primative data type, 
*/