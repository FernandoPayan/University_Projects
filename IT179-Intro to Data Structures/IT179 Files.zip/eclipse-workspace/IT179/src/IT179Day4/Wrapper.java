package IT179Day4;

import java.util.ArrayList;

public class Wrapper {

	public static void main(String[] args) {
		/*ArrayList<Integer> list = new ArrayList<Integer>();
		int a = Integer.parseInt("5");
		System.out.println(a + 1);
		
		System.out.println(Character.isDigit('1'));
		list.add(5);
		*/
	}

}

// Character. , Integer. , Double. , are examples of Wrapper classes.