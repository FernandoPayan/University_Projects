package ITDay179Day9_10;

import java.util.InputMismatchException;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num = 0;
		try {
		System.out.println("Enter a number: ");
		num = input.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Wrong");
			main(null);
		}
		for (int i = 0; i < 2; i++)
			System.out.println("Num is " + num);
		input.close();
	}

}

/*
Exam 3 - November 4th
Starts at double linked lists


*/