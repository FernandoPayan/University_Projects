#include <sys/types.h>  /* needed to use pid_t, etc. */
#include <sys/wait.h>   /* needed to use wait() */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>     /* LIMUX constants and functions (fork(), etc.) */

int main()
{
    pid_t cid;

    cid = fork();
    int execlp_val;

    if (cid < 0)
    {
        printf("A fork error has occured.\n");
        exit(-1);
    }
    else
        if (cid == 0) /* We are in the child */
        {
            printf("I am the child, about to call ps using execlp. \n");
            execlp_val = execlp("/bin/ls", "ls", (char *) 0);

            /*  If execlp() is successful, we should not reach this next line. */
            printf("The call to exclp() was not successful.\n");
            exit(127);
        }
        else /* We are in the parent. */
        {
            int wait_val = wait(0);            /* Wait for the child to terminate. */
            
            /* Check the return value/error code of wait function call */
            if (wait_val == -1)
            {
                printf("The call to wait() was not successful.\n");
                exit(127);
            }

            /* Exiting program */
            printf("I am the parent. The child just ended. I will now exit.\n");
            exit(0);
        }
    return(0);
}